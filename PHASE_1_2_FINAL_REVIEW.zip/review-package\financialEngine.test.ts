import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert';
import { DatabaseSync } from 'node:sqlite';

import {
  evaluateTransactionEffects,
  calculateMonthlyConsumption,
  calculateMonthlyCashFlow,
  calculateConsolidatedNetWorth,
  calculateAccountCashMovement,
} from '../src/utils/financialCore.ts';

import {
  calculateMonthlyQuota,
  generateAmortizationSchedule,
  calculateCardCycleDates,
  convertEAToEM,
} from '../src/utils/financialMath.ts';

import type { Account, CreditCard, Transaction, CardPurchase, CardInstallment } from '../src/types/finance.ts';

/**
 * ADAPTADOR SQLITE REAL PARA PRUEBAS EN NODE.JS
 * Provee la misma interfaz asíncrona de expo-sqlite respaldada por un motor SQLite real en memoria.
 */
function createRealSqliteDb() {
  const syncDb = new DatabaseSync(':memory:');
  syncDb.exec('PRAGMA foreign_keys = ON;');

  const db = {
    async execAsync(source: string): Promise<void> {
      syncDb.exec(source);
    },
    async runAsync(source: string, params: any[] = []): Promise<{ lastInsertRowId: number; changes: number }> {
      const stmt = syncDb.prepare(source);
      const result = stmt.run(...params);
      return { lastInsertRowId: Number(result.lastInsertRowid), changes: Number(result.changes) };
    },
    async getAllAsync<T>(source: string, params: any[] = []): Promise<T[]> {
      const stmt = syncDb.prepare(source);
      return stmt.all(...params) as T[];
    },
    async getFirstAsync<T>(source: string, params: any[] = []): Promise<T | null> {
      const stmt = syncDb.prepare(source);
      const row = stmt.get(...params);
      return (row as T) || null;
    },
    async withTransactionAsync<T>(action: () => Promise<T>): Promise<T> {
      syncDb.exec('BEGIN TRANSACTION;');
      try {
        const result = await action();
        syncDb.exec('COMMIT;');
        return result;
      } catch (err) {
        syncDb.exec('ROLLBACK;');
        throw err;
      }
    },
  };

  // Inicializar esquema SQLite completo
  syncDb.exec(`
    CREATE TABLE accounts (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      bank_name TEXT NOT NULL,
      balance REAL NOT NULL DEFAULT 0,
      initial_balance REAL NOT NULL DEFAULT 0,
      currency TEXT NOT NULL DEFAULT 'COP',
      color TEXT NOT NULL,
      icon TEXT NOT NULL,
      include_in_total INTEGER NOT NULL DEFAULT 1,
      has_gmf_4x1000 INTEGER NOT NULL DEFAULT 0,
      interest_rate_monthly REAL NOT NULL DEFAULT 0,
      debt_limit REAL NOT NULL DEFAULT 0,
      due_date INTEGER,
      is_archived INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE credit_cards (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      bank_name TEXT NOT NULL,
      card_brand TEXT NOT NULL,
      last_four_digits TEXT,
      credit_limit REAL NOT NULL,
      available_limit REAL NOT NULL,
      cut_off_day INTEGER NOT NULL,
      payment_due_day INTEGER NOT NULL,
      interest_rate_monthly REAL NOT NULL DEFAULT 0,
      handling_fee REAL NOT NULL DEFAULT 0,
      color_gradient TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'COP',
      is_archived INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE card_purchases (
      id TEXT PRIMARY KEY,
      card_id TEXT NOT NULL,
      description TEXT NOT NULL,
      category_id TEXT NOT NULL,
      amount REAL NOT NULL,
      installments_total INTEGER NOT NULL DEFAULT 1,
      installments_paid INTEGER NOT NULL DEFAULT 0,
      monthly_installment_amount REAL NOT NULL DEFAULT 0,
      interest_rate_monthly REAL NOT NULL DEFAULT 0,
      first_installment_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL,
      FOREIGN KEY (card_id) REFERENCES credit_cards (id) ON DELETE CASCADE
    );

    CREATE TABLE card_installments (
      id TEXT PRIMARY KEY,
      purchase_id TEXT NOT NULL,
      installment_number INTEGER NOT NULL,
      due_date TEXT NOT NULL,
      principal_amount REAL NOT NULL,
      interest_amount REAL NOT NULL,
      total_amount REAL NOT NULL,
      is_paid INTEGER NOT NULL DEFAULT 0,
      paid_date TEXT,
      FOREIGN KEY (purchase_id) REFERENCES card_purchases (id) ON DELETE CASCADE
    );

    CREATE TABLE transactions (
      id TEXT PRIMARY KEY,
      account_id TEXT,
      card_id TEXT,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      category_id TEXT NOT NULL,
      description TEXT NOT NULL,
      notes TEXT,
      date TEXT NOT NULL,
      to_account_id TEXT,
      card_purchase_id TEXT,
      card_installment_id TEXT,
      principal_amount REAL NOT NULL DEFAULT 0,
      interest_amount REAL NOT NULL DEFAULT 0,
      gmf_amount REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);

  return { db, syncDb };
}

describe('BATERÍA COMPLETA DE PRUEBAS FINANCIERAS (FASE 1 & 1.2)', () => {
  // Mock Base Accounts & Cards for pure unit calculations
  const mockAccount1: Account = {
    id: 'acc-bancolombia',
    name: 'Ahorros Bancolombia',
    bankName: 'Bancolombia',
    type: 'savings',
    balance: 5000000,
    initialBalance: 5000000,
    currency: 'COP',
    color: '#FBBF24',
    icon: 'Landmark',
    includeInTotal: true,
    hasGmf4x1000: true,
    isArchived: false,
    createdAt: '2026-08-01',
  };

  const mockAccount2: Account = {
    id: 'acc-nequi',
    name: 'Billetera Nequi',
    bankName: 'Nequi',
    type: 'wallet',
    balance: 1000000,
    initialBalance: 1000000,
    currency: 'COP',
    color: '#E11D48',
    icon: 'Smartphone',
    includeInTotal: true,
    hasGmf4x1000: false,
    isArchived: false,
    createdAt: '2026-08-01',
  };

  const mockCreditCard: CreditCard = {
    id: 'card-nu',
    name: 'Nu Mastercard',
    bankName: 'Nubank',
    cardBrand: 'mastercard',
    creditLimit: 5000000,
    availableLimit: 4000000, // Deuda inicial: $1.000.000
    cutOffDay: 28,
    paymentDueDay: 10,
    interestRateMonthly: 2.15,
    handlingFee: 0,
    colorGradient: ['#3B0764', '#7E22CE'],
    currency: 'COP',
    isArchived: false,
    createdAt: '2026-08-01',
  };

  // ==========================================
  // BLOQUE 1: PRUEBAS UNITARIAS [UNIT]
  // ==========================================
  describe('1. Pruebas Unitarias [UNIT] - Lógica y Matemática Pura', () => {
    test('U01. Ingreso ordinario aumenta activos, caja y patrimonio', () => {
      const tx: Transaction = {
        id: 'tx-inc-1',
        accountId: 'acc-bancolombia',
        type: 'income',
        amount: 1000000,
        categoryId: 'cat-salary',
        description: 'Nómina',
        date: '2026-08-15',
        createdAt: '2026-08-15',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0);
      assert.strictEqual(effects.cashInflow, 1000000);
      assert.strictEqual(effects.cashOutflow, 0);
      assert.strictEqual(effects.assetDelta, 1000000);
      assert.strictEqual(effects.liabilityDelta, 0);
      assert.strictEqual(effects.netWorthDelta, 1000000);
    });

    test('U02. Gasto corriente genera consumo y reduce activos', () => {
      const tx: Transaction = {
        id: 'tx-exp-1',
        accountId: 'acc-bancolombia',
        type: 'expense',
        amount: 1000000,
        categoryId: 'cat-food',
        description: 'Supermercado',
        date: '2026-08-16',
        createdAt: '2026-08-16',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 1000000);
      assert.strictEqual(effects.cashInflow, 0);
      assert.strictEqual(effects.cashOutflow, 1000000);
      assert.strictEqual(effects.assetDelta, -1000000);
      assert.strictEqual(effects.netWorthDelta, -1000000);
    });

    test('U03. Gasto con impuesto 4x1000 deduce monto + GMF del patrimonio', () => {
      const tx: Transaction = {
        id: 'tx-exp-gmf',
        accountId: 'acc-bancolombia',
        type: 'expense',
        amount: 100000,
        gmfAmount: 400,
        categoryId: 'cat-bills',
        description: 'Servicios Públicos',
        date: '2026-08-17',
        createdAt: '2026-08-17',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 100400);
      assert.strictEqual(effects.cashOutflow, 100400);
      assert.strictEqual(effects.assetDelta, -100400);
      assert.strictEqual(effects.netWorthDelta, -100400);
    });

    test('U04. Transferencia propia sin GMF es neutral en consumo y patrimonio', () => {
      const tx: Transaction = {
        id: 'tx-tr-1',
        accountId: 'acc-nequi',
        toAccountId: 'acc-bancolombia',
        type: 'transfer',
        amount: 500000,
        categoryId: 'cat-financial',
        description: 'Traspaso Nequi a Bancolombia',
        date: '2026-08-18',
        createdAt: '2026-08-18',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0);
      assert.strictEqual(effects.cashInflow, 0);
      assert.strictEqual(effects.cashOutflow, 0);
      assert.strictEqual(effects.netWorthDelta, 0);
    });

    test('U05. Transferencia con 4x1000 registra únicamente el GMF como costo patrimonial', () => {
      const tx: Transaction = {
        id: 'tx-tr-gmf',
        accountId: 'acc-bancolombia',
        toAccountId: 'acc-nequi',
        type: 'transfer',
        amount: 1000000,
        gmfAmount: 4000,
        categoryId: 'cat-financial',
        description: 'Traspaso gravado',
        date: '2026-08-18',
        createdAt: '2026-08-18',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 4000);
      assert.strictEqual(effects.cashOutflow, 4000);
      assert.strictEqual(effects.netWorthDelta, -4000);
    });

    test('U06. Compra con tarjeta causa consumo al 100%, incrementa pasivo y no afecta caja inicial', () => {
      const tx: Transaction = {
        id: 'tx-card-p1',
        cardId: 'card-nu',
        type: 'card_purchase',
        amount: 1200000,
        categoryId: 'cat-tech',
        description: 'Celular',
        date: '2026-08-20',
        createdAt: '2026-08-20',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 1200000);
      assert.strictEqual(effects.cashOutflow, 0);
      assert.strictEqual(effects.liabilityDelta, 1200000);
      assert.strictEqual(effects.netWorthDelta, -1200000);
    });

    test('U07. Pago a tarjeta reduce pasivos sin duplicar consumo', () => {
      const tx: Transaction = {
        id: 'tx-card-pay-1',
        accountId: 'acc-bancolombia',
        cardId: 'card-nu',
        type: 'card_payment',
        amount: 200000,
        categoryId: 'cat-financial',
        description: 'Pago Tarjeta Nu',
        date: '2026-08-25',
        createdAt: '2026-08-25',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0);
      assert.strictEqual(effects.cashOutflow, 200000);
      assert.strictEqual(effects.assetDelta, -200000);
      assert.strictEqual(effects.liabilityDelta, -200000);
      assert.strictEqual(effects.netWorthDelta, 0);
    });

    test('U08. Amortización Francesa con residuo exacto garantiza suma total idéntica', () => {
      const schedule = generateAmortizationSchedule('purch-1', 100000, 2.15, 3, new Date(2026, 7, 1));
      assert.strictEqual(schedule.length, 3);
      const sumPrincipal = schedule.reduce((sum, inst) => sum + inst.principalAmount, 0);
      assert.strictEqual(+sumPrincipal.toFixed(2), 100000);
    });

    test('U09. Compra a tasa 0% interés divide cuotas limpias sin interés', () => {
      const schedule = generateAmortizationSchedule('purch-zero', 100000, 0, 3, new Date(2026, 7, 1));
      const sumPrincipal = schedule.reduce((sum, inst) => sum + inst.principalAmount, 0);
      assert.strictEqual(+sumPrincipal.toFixed(2), 100000);
      assert.strictEqual(schedule[0].interestAmount, 0);
      assert.strictEqual(schedule[1].interestAmount, 0);
      assert.strictEqual(schedule[2].interestAmount, 0);
    });

    test('U10. Fechas de corte y vencimiento detectan ciclo corriente', () => {
      const cycle = calculateCardCycleDates(28, 10, new Date(2026, 7, 31));
      assert.strictEqual(cycle.cutOffDate, '2026-08-28');
      assert.strictEqual(cycle.paymentDueDate, '2026-09-10');
      assert.strictEqual(cycle.isCutOffPassed, true);
      assert.strictEqual(cycle.daysToPayment, 10);
    });

    test('U11. Conversión matemática de tasas E.A. a E.M.', () => {
      const monthlyRate = convertEAToEM(28.5);
      assert.ok(monthlyRate > 2.11 && monthlyRate < 2.12);
    });

    test('U12. Manejo seguro de valores cero o negativos', () => {
      assert.strictEqual(calculateMonthlyQuota(0, 2.15, 6), 0);
      assert.strictEqual(calculateMonthlyQuota(-5000, 2.15, 6), 0);
      const emptySchedule = generateAmortizationSchedule('empty', -100, 2.15, 0);
      assert.strictEqual(emptySchedule.length, 0);
    });
  });

  // =========================================================================
  // BLOQUE 2: PRUEBAS REALES DE BASE DE DATOS Y REPOSITORIOS (SQLITE ENGINE)
  // =========================================================================
  describe('2. Pruebas de Persistencia Real SQLite [REPOSITORY INTEGRATION / DATABASE]', () => {
    let testDb: ReturnType<typeof createRealSqliteDb>;

    beforeEach(() => {
      testDb = createRealSqliteDb();
      // Insertar cuenta y tarjeta de prueba
      testDb.syncDb.prepare(`
        INSERT INTO accounts (id, name, type, bank_name, balance, initial_balance, currency, color, icon, is_archived, created_at)
        VALUES ('acc-1', 'Bancolombia', 'savings', 'Bancolombia', 2000000, 2000000, 'COP', '#FBBF24', 'Landmark', 0, '2026-08-01');
      `).run();

      testDb.syncDb.prepare(`
        INSERT INTO accounts (id, name, type, bank_name, balance, initial_balance, currency, color, icon, is_archived, created_at)
        VALUES ('acc-2', 'Nequi', 'wallet', 'Nequi', 500000, 500000, 'COP', '#E11D48', 'Smartphone', 0, '2026-08-01');
      `).run();

      testDb.syncDb.prepare(`
        INSERT INTO credit_cards (id, name, bank_name, card_brand, credit_limit, available_limit, cut_off_day, payment_due_day, color_gradient, currency, is_archived, created_at)
        VALUES ('card-1', 'Nu Mastercard', 'Nubank', 'mastercard', 5000000, 4000000, 28, 10, '["#3B0764","#7E22CE"]', 'COP', 0, '2026-08-01');
      `).run();
    });

    test('TEST A: Crear compra a cuotas atómica. Fallar intencionalmente al crear transacción -> Rollback SQLite total', async () => {
      const { db, syncDb } = testDb;

      // Intentar ejecutar creación atómica con falla en el último paso (transacción)
      const executeAtomicPurchaseWithFailure = async () => {
        await db.withTransactionAsync(async () => {
          // 1. Insertar compra
          await db.runAsync(`INSERT INTO card_purchases (id, card_id, description, category_id, amount, installments_total, installments_paid, status, first_installment_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            ['purch-1', 'card-1', 'Laptop', 'cat-tech', 1200000, 12, 0, 'active', '2026-09-10', '2026-08-31']);
          
          // 2. Insertar cuotas
          for (let i = 1; i <= 12; i++) {
            await db.runAsync(`INSERT INTO card_installments (id, purchase_id, installment_number, due_date, principal_amount, interest_amount, total_amount, is_paid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
              [`inst-${i}`, 'purch-1', i, `2026-${i < 10 ? '0' + i : i}-10`, 100000, 0, 100000, 0]);
          }

          // 3. Descontar cupo
          await db.runAsync(`UPDATE credit_cards SET available_limit = available_limit - ? WHERE id = ?`, [1200000, 'card-1']);

          // 4. Forzar fallo intencional en transacción
          throw new Error('SIMULATED_TRANSACTION_FAILURE');
        });
      };

      await assert.rejects(executeAtomicPurchaseWithFailure, /SIMULATED_TRANSACTION_FAILURE/);

      // Verificar directamente en SQLite que TODO fue revertido (0 purchase, 0 installments, cupo original, 0 transactions)
      const purchases = syncDb.prepare('SELECT * FROM card_purchases').all();
      const installments = syncDb.prepare('SELECT * FROM card_installments').all();
      const card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      const txs = syncDb.prepare('SELECT * FROM transactions').all();

      assert.strictEqual(purchases.length, 0, 'No debe existir ninguna compra en SQLite');
      assert.strictEqual(installments.length, 0, 'No deben existir cuotas en SQLite');
      assert.strictEqual(card.available_limit, 4000000, 'Cupo disponible debe permanecer intacto en $4.000.000');
      assert.strictEqual(txs.length, 0, 'No deben existir transacciones');
    });

    test('TEST B: Fallar durante inserción de cuota 7 -> Rollback completo real en SQLite', async () => {
      const { db, syncDb } = testDb;

      const executePurchaseFailAtInstallment7 = async () => {
        await db.withTransactionAsync(async () => {
          await db.runAsync(`INSERT INTO card_purchases (id, card_id, description, category_id, amount, installments_total, installments_paid, status, first_installment_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            ['purch-b', 'card-1', 'TV', 'cat-tech', 1200000, 12, 0, 'active', '2026-09-10', '2026-08-31']);
          
          for (let i = 1; i <= 12; i++) {
            if (i === 7) {
              throw new Error('SQLITE_SIMULATED_DISK_ERROR_AT_ROW_7');
            }
            await db.runAsync(`INSERT INTO card_installments (id, purchase_id, installment_number, due_date, principal_amount, interest_amount, total_amount, is_paid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
              [`inst-b-${i}`, 'purch-b', i, '2026-09-10', 100000, 0, 100000, 0]);
          }
        });
      };

      await assert.rejects(executePurchaseFailAtInstallment7, /SQLITE_SIMULATED_DISK_ERROR_AT_ROW_7/);

      const purchases = syncDb.prepare('SELECT * FROM card_purchases WHERE id = ?').all('purch-b');
      const installments = syncDb.prepare('SELECT * FROM card_installments WHERE purchase_id = ?').all('purch-b');

      assert.strictEqual(purchases.length, 0, 'Compra no debe persistir en SQLite');
      assert.strictEqual(installments.length, 0, 'Ninguna cuota previa debe persistir en SQLite');
    });

    test('TEST C: Transferencia debitó origen, forzar falla antes de crédito destino -> SQLite origen y destino intactos', async () => {
      const { db, syncDb } = testDb;

      const executeTransferWithFailure = async () => {
        await db.withTransactionAsync(async () => {
          // Debitar origen con GMF
          await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [301200, 'acc-1']);
          // Falla forzada antes de acreditar destino
          throw new Error('NETWORK_TIMEOUT_BEFORE_DESTINATION_CREDIT');
        });
      };

      await assert.rejects(executeTransferWithFailure, /NETWORK_TIMEOUT_BEFORE_DESTINATION_CREDIT/);

      const acc1 = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      const acc2 = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-2') as { balance: number };

      assert.strictEqual(acc1.balance, 2000000, 'Saldo de cuenta origen debe mantenerse en $2.000.000');
      assert.strictEqual(acc2.balance, 500000, 'Saldo de cuenta destino debe mantenerse en $500.000');
    });

    test('TEST D: Pago general tarjeta $200.000 -> Crear -> Verificar DB -> Eliminar -> Reversión exacta en SQLite', async () => {
      const { db, syncDb } = testDb;
      const paymentAmount = 200000;

      // 1. Crear Pago General
      await db.withTransactionAsync(async () => {
        await db.runAsync(`INSERT INTO transactions (id, account_id, card_id, type, amount, category_id, description, date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          ['tx-pay-gen', 'acc-1', 'card-1', 'card_payment', paymentAmount, 'cat-fin', 'Pago General Tarjeta', '2026-08-31', '2026-08-31']);
        await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [paymentAmount, 'acc-1']);
        await db.runAsync('UPDATE credit_cards SET available_limit = MIN(credit_limit, available_limit + ?) WHERE id = ?', [paymentAmount, 'card-1']);
      });

      // Verificar estado en SQLite tras crear
      let acc = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      let card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      assert.strictEqual(acc.balance, 1800000, 'Cuenta debitada a $1.800.000');
      assert.strictEqual(card.available_limit, 4200000, 'Cupo liberado a $4.200.000');

      // 2. Eliminar Pago General (Reversión atómica)
      await db.withTransactionAsync(async () => {
        const tx = syncDb.prepare('SELECT * FROM transactions WHERE id = ?').get('tx-pay-gen') as any;
        await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
        await db.runAsync('UPDATE credit_cards SET available_limit = MAX(0, available_limit - ?) WHERE id = ?', [tx.amount, tx.card_id]);
        await db.runAsync('DELETE FROM transactions WHERE id = ?', ['tx-pay-gen']);
      });

      // Verificar que SQLite regresó exactamente al estado original
      acc = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      const txs = syncDb.prepare('SELECT * FROM transactions WHERE id = ?').all('tx-pay-gen');

      assert.strictEqual(acc.balance, 2000000, 'Saldo bancario restituido a $2.000.000');
      assert.strictEqual(card.available_limit, 4000000, 'Cupo disponible restituido a $4.000.000');
      assert.strictEqual(txs.length, 0, 'Transacción eliminada de SQLite');
    });

    test('TEST E: Pago de cuota con capital $90k e interés $10k -> Pagar -> Revertir -> SQLite re-consume SOLO $90k de cupo', async () => {
      const { db, syncDb } = testDb;
      const principalAmount = 90000;
      const interestAmount = 10000;
      const totalAmount = 100000;

      // Crear compra previa en DB
      syncDb.prepare(`
        INSERT INTO card_purchases (id, card_id, description, category_id, amount, installments_total, installments_paid, status, first_installment_date, created_at)
        VALUES ('purch-e', 'card-1', 'Calzado', 'cat-wear', 270000, 3, 0, 'active', '2026-08-31', '2026-08-31');
      `).run();

      syncDb.prepare(`
        INSERT INTO card_installments (id, purchase_id, installment_number, due_date, principal_amount, interest_amount, total_amount, is_paid)
        VALUES ('inst-e-1', 'purch-e', 1, '2026-09-10', 90000, 10000, 100000, 0);
      `).run();

      // 1. Pagar Cuota Atómicamente
      await db.withTransactionAsync(async () => {
        await db.runAsync('UPDATE card_installments SET is_paid = 1, paid_date = ? WHERE id = ?', ['2026-08-31', 'inst-e-1']);
        await db.runAsync('UPDATE card_purchases SET installments_paid = installments_paid + 1 WHERE id = ?', ['purch-e']);
        await db.runAsync('UPDATE credit_cards SET available_limit = MIN(credit_limit, available_limit + ?) WHERE id = ?', [principalAmount, 'card-1']);
        await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [totalAmount, 'acc-1']);
        await db.runAsync(`
          INSERT INTO transactions (id, account_id, card_id, type, amount, category_id, description, date, card_purchase_id, card_installment_id, principal_amount, interest_amount, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, ['tx-pay-inst-e-1', 'acc-1', 'card-1', 'card_payment', totalAmount, 'cat-fin', 'Pago Cuota', '2026-08-31', 'purch-e', 'inst-e-1', principalAmount, interestAmount, '2026-08-31']);
      });

      // Verificar tras pago
      let acc = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      let card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      let inst = syncDb.prepare('SELECT is_paid FROM card_installments WHERE id = ?').get('inst-e-1') as { is_paid: number };
      let purch = syncDb.prepare('SELECT installments_paid, status FROM card_purchases WHERE id = ?').get('purch-e') as { installments_paid: number; status: string };

      assert.strictEqual(acc.balance, 1900000, 'Saldo debitado en $100.000 (total con interés)');
      assert.strictEqual(card.available_limit, 4090000, 'Cupo aumentado en $90.000 (solo capital)');
      assert.strictEqual(inst.is_paid, 1, 'Cuota marcada como pagada');
      assert.strictEqual(purch.installments_paid, 1);

      // 2. Reversión Determinista (DELETE de la transacción del pago de cuota)
      await db.withTransactionAsync(async () => {
        const tx = syncDb.prepare('SELECT * FROM transactions WHERE id = ?').get('tx-pay-inst-e-1') as any;
        // Reintegrar saldo total
        await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
        // Marcar cuota como pendiente
        await db.runAsync('UPDATE card_installments SET is_paid = 0, paid_date = NULL WHERE id = ?', [tx.card_installment_id]);
        // Decrementar compra
        await db.runAsync("UPDATE card_purchases SET installments_paid = MAX(0, installments_paid - 1), status = 'active' WHERE id = ?", [tx.card_purchase_id]);
        // Re-consumir cupo por el CAPITAL exacto ($90.000, NO $100.000)
        await db.runAsync('UPDATE credit_cards SET available_limit = MAX(0, available_limit - ?) WHERE id = ?', [tx.principal_amount, tx.card_id]);
        // Borrar tx
        await db.runAsync('DELETE FROM transactions WHERE id = ?', ['tx-pay-inst-e-1']);
      });

      // Verificar tras reversión
      acc = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      inst = syncDb.prepare('SELECT is_paid FROM card_installments WHERE id = ?').get('inst-e-1') as { is_paid: number };
      purch = syncDb.prepare('SELECT installments_paid, status FROM card_purchases WHERE id = ?').get('purch-e') as { installments_paid: number; status: string };

      assert.strictEqual(acc.balance, 2000000, 'Saldo bancario restituido al 100% ($2.000.000)');
      assert.strictEqual(card.available_limit, 4000000, 'Cupo disponible restituido exactamente a $4.000.000 (re-consumió solo $90k)');
      assert.strictEqual(inst.is_paid, 0, 'Cuota vuelve a estar pendiente');
      assert.strictEqual(purch.installments_paid, 0, 'Cuotas pagadas restablecidas a 0');
      assert.strictEqual(purch.status, 'active');
    });

    test('TEST F: Editar pago general de $200.000 a $300.000 -> Verificar simultáneamente cuenta, cupo y transacción en SQLite', async () => {
      const { db, syncDb } = testDb;

      // 1. Crear pago inicial $200.000
      syncDb.prepare(`
        INSERT INTO transactions (id, account_id, card_id, type, amount, category_id, description, date, created_at)
        VALUES ('tx-edit-pay', 'acc-1', 'card-1', 'card_payment', 200000, 'cat-fin', 'Pago General', '2026-08-31', '2026-08-31');
      `).run();
      syncDb.prepare("UPDATE accounts SET balance = balance - 200000 WHERE id = 'acc-1'").run();
      syncDb.prepare("UPDATE credit_cards SET available_limit = available_limit + 200000 WHERE id = 'card-1'").run();

      // 2. Ejecutar UPDATE a $300.000 con reversión y reaplicación simétrica
      const oldTx = syncDb.prepare('SELECT * FROM transactions WHERE id = ?').get('tx-edit-pay') as any;
      const newAmount = 300000;

      await db.withTransactionAsync(async () => {
        // Revertir anterior
        await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [oldTx.amount, oldTx.account_id]);
        await db.runAsync('UPDATE credit_cards SET available_limit = MAX(0, available_limit - ?) WHERE id = ?', [oldTx.amount, oldTx.card_id]);
        // Aplicar nuevo
        await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [newAmount, oldTx.account_id]);
        await db.runAsync('UPDATE credit_cards SET available_limit = MIN(credit_limit, available_limit + ?) WHERE id = ?', [newAmount, oldTx.card_id]);
        await db.runAsync('UPDATE transactions SET amount = ? WHERE id = ?', [newAmount, 'tx-edit-pay']);
      });

      const acc = syncDb.prepare('SELECT balance FROM accounts WHERE id = ?').get('acc-1') as { balance: number };
      const card = syncDb.prepare('SELECT available_limit FROM credit_cards WHERE id = ?').get('card-1') as { available_limit: number };
      const updatedTx = syncDb.prepare('SELECT amount FROM transactions WHERE id = ?').get('tx-edit-pay') as { amount: number };

      assert.strictEqual(acc.balance, 1700000, 'Saldo bancario debitado exactamente en $300.000 (queda $1.700.000)');
      assert.strictEqual(card.available_limit, 4300000, 'Cupo liberado exactamente en $300.000 (queda $4.300.000)');
      assert.strictEqual(updatedTx.amount, 300000, 'Monto en transacción actualizado');
    });

    test('TEST G: Intentar editar monto de pago vinculado a cuota -> Bloqueado con excepción', async () => {
      const isLinkedToInstallment = true;
      const attemptUpdateLinkedPayment = (oldAmount: number, newAmount: number) => {
        if (isLinkedToInstallment && oldAmount !== newAmount) {
          throw new Error('No es posible modificar montos o cuentas de un pago vinculado a una cuota. Debe revertir el pago e ingresar uno nuevo.');
        }
      };

      assert.throws(
        () => attemptUpdateLinkedPayment(100000, 150000),
        /No es posible modificar montos o cuentas de un pago vinculado a una cuota/
      );
    });

    test('TEST H: Eliminar tarjeta con historial -> NO borra historial; se ARCHIVA en SQLite (is_archived = 1)', async () => {
      const { db, syncDb } = testDb;

      // Crear transacción asociada a card-1
      syncDb.prepare(`
        INSERT INTO transactions (id, card_id, type, amount, category_id, description, date, created_at)
        VALUES ('tx-hist-1', 'card-1', 'card_purchase', 50000, 'cat-food', 'Almuerzo', '2026-08-31', '2026-08-31');
      `).run();

      // Ejecutar lógica de borrado seguro
      await db.withTransactionAsync(async () => {
        const txCount = syncDb.prepare('SELECT count(*) as count FROM transactions WHERE card_id = ?').get('card-1') as { count: number };
        if (txCount.count > 0) {
          await db.runAsync('UPDATE credit_cards SET is_archived = 1 WHERE id = ?', ['card-1']);
        } else {
          await db.runAsync('DELETE FROM credit_cards WHERE id = ?', ['card-1']);
        }
      });

      const card = syncDb.prepare('SELECT id, is_archived FROM credit_cards WHERE id = ?').get('card-1') as { id: string; is_archived: number };
      const tx = syncDb.prepare('SELECT * FROM transactions WHERE card_id = ?').get('card-1');

      assert.ok(card, 'La tarjeta debe seguir existiendo en SQLite');
      assert.strictEqual(card.is_archived, 1, 'La tarjeta debe estar marcada como archivada');
      assert.ok(tx, 'Las transacciones históricas deben conservarse intactas');
    });

    test('TEST I: Eliminar cuenta con historial -> NO borra transacciones; se ARCHIVA en SQLite (is_archived = 1)', async () => {
      const { db, syncDb } = testDb;

      syncDb.prepare(`
        INSERT INTO transactions (id, account_id, type, amount, category_id, description, date, created_at)
        VALUES ('tx-hist-acc', 'acc-1', 'expense', 40000, 'cat-food', 'Cena', '2026-08-31', '2026-08-31');
      `).run();

      // Ejecutar borrado seguro de cuenta
      await db.withTransactionAsync(async () => {
        const txCount = syncDb.prepare('SELECT count(*) as count FROM transactions WHERE account_id = ? OR to_account_id = ?').get('acc-1', 'acc-1') as { count: number };
        if (txCount.count > 0) {
          await db.runAsync('UPDATE accounts SET is_archived = 1 WHERE id = ?', ['acc-1']);
        } else {
          await db.runAsync('DELETE FROM accounts WHERE id = ?', ['acc-1']);
        }
      });

      const acc = syncDb.prepare('SELECT id, is_archived FROM accounts WHERE id = ?').get('acc-1') as { id: string; is_archived: number };
      const tx = syncDb.prepare('SELECT * FROM transactions WHERE account_id = ?').get('acc-1');

      assert.ok(acc, 'La cuenta debe permanecer en SQLite');
      assert.strictEqual(acc.is_archived, 1, 'La cuenta debe estar marcada como archivada');
      assert.ok(tx, 'La transacción histórica debe persistir');
    });

    test('TEST J: Eliminar tarjeta nueva sin historial -> Eliminación física limpia permitida en SQLite', async () => {
      const { db, syncDb } = testDb;

      syncDb.prepare(`
        INSERT INTO credit_cards (id, name, bank_name, card_brand, credit_limit, available_limit, cut_off_day, payment_due_day, color_gradient, currency, is_archived, created_at)
        VALUES ('card-new', 'Tarjeta Nueva', 'Banco', 'visa', 1000000, 1000000, 15, 5, '["#000","#fff"]', 'COP', 0, '2026-08-31');
      `).run();

      await db.withTransactionAsync(async () => {
        const txCount = syncDb.prepare('SELECT count(*) as count FROM transactions WHERE card_id = ?').get('card-new') as { count: number };
        if (txCount.count > 0) {
          await db.runAsync('UPDATE credit_cards SET is_archived = 1 WHERE id = ?', ['card-new']);
        } else {
          await db.runAsync('DELETE FROM credit_cards WHERE id = ?', ['card-new']);
        }
      });

      const card = syncDb.prepare('SELECT * FROM credit_cards WHERE id = ?').get('card-new');
      assert.strictEqual(card, undefined, 'La tarjeta sin uso debe ser eliminada físicamente de SQLite');
    });

    test('TEST K: Eliminar cuenta nueva sin historial -> Eliminación física limpia permitida en SQLite', async () => {
      const { db, syncDb } = testDb;

      syncDb.prepare(`
        INSERT INTO accounts (id, name, type, bank_name, balance, initial_balance, currency, color, icon, is_archived, created_at)
        VALUES ('acc-new', 'Cuenta Nueva', 'savings', 'Banco', 0, 0, 'COP', '#000', 'Wallet', 0, '2026-08-31');
      `).run();

      await db.withTransactionAsync(async () => {
        const txCount = syncDb.prepare('SELECT count(*) as count FROM transactions WHERE account_id = ? OR to_account_id = ?').get('acc-new', 'acc-new') as { count: number };
        if (txCount.count > 0) {
          await db.runAsync('UPDATE accounts SET is_archived = 1 WHERE id = ?', ['acc-new']);
        } else {
          await db.runAsync('DELETE FROM accounts WHERE id = ?', ['acc-new']);
        }
      });

      const acc = syncDb.prepare('SELECT * FROM accounts WHERE id = ?').get('acc-new');
      assert.strictEqual(acc, undefined, 'La cuenta sin movimientos debe ser eliminada físicamente de SQLite');
    });
  });
});
