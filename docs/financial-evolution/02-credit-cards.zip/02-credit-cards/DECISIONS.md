# REGISTRO DE DECISIONES DE ARQUITECTURA (ADR) — FASE 2: TARJETAS DE CRÉDITO

## ADR-01: Separación Estricta de los Tres Saldos Financieros
- **Contexto:** En el modelo previo, se presentaba una única cifra de deuda o cupo usado, lo cual inducía a error entre lo que ya cortó en el extracto mensual y lo que se gastó posteriormente.
- **Decisión:** Implementar y diferenciar permanentemente 3 saldos:
  1. `Deuda Total Actual`: Todo el cupo consumido pendiente (`creditLimit - availableLimit`).
  2. `Deuda Facturada Pendiente`: Saldo que cerró en el último extracto menos los abonos recibidos (`totalStatementBalance - statementBalancePaid`).
  3. `Deuda No Facturada`: Consumos realizados después de la fecha de corte que entrarán en el próximo periodo.
- **Consecuencia:** Claridad contable absoluta. El usuario sabe exactamente cuánto debe pagar para no generar intereses de mora vs cuánto debe en total.

---

## ADR-02: Liberación de Cupo Exclusivamente por Capital Amortizado (Payment Allocation)
- **Contexto:** Si un usuario abona $150.000 a una tarjeta pero $50.000 corresponden a intereses y comisiones de manejo, el cupo disponible NO puede incrementarse en $150.000, sino únicamente en los $100.000 de capital real amortizado.
- **Decisión:** Modelar la tabla `card_payment_allocations` y el método `payCreditCardAtomic`. Al registrar un pago, el motor aplica la política bancaria del emisor y solo añade `principalApplied` a `availableLimit`.
- **Consecuencia:** Exactitud contable estricta en el cupo disponible de la tarjeta en SQLite.

---

## ADR-03: Motor de Políticas por Emisor Bancario (`CreditCardIssuerPolicy`)
- **Contexto:** Cada banco en Colombia procesa los pagos con prelaciones legales y reglas de negocio distintas:
  - *Nu Colombia:* Permite pagos anticipados y cancelación de cuotas; orden: impuestos -> cargos -> mora -> corriente -> capital.
  - *Bancolombia:* No permite pagos dirigidos a compras individuales; imputa por prelación legal estricta.
  - *RappiCard:* Tras cubrir cargos mínimos, el 100% del excedente se abona a capital.
- **Decisión:** Crear una jerarquía de políticas en `src/utils/issuerPolicies/` (`NuPolicy`, `BancolombiaPolicy`, `RappiCardPolicy`, `GenericPolicy`) con un Factory `getIssuerPolicy(card.issuerId)`.
- **Consecuencia:** Flexibilidad bancaria sin sobrearquitectura, facilitando añadir nuevos emisores (Davivienda, BBVA, etc.) en el futuro.

---

## ADR-04: Conciliación Bancaria con Auditoría de Ajustes
- **Contexto:** Los bancos aplican seguros, redondeos o comisiones no registradas de inmediato en la app.
- **Decisión:** Crear el módulo `card_reconciliations`. Al detectar una diferencia, el usuario puede generar un `balance_adjustment` en el libro mayor (`transactions`), auditando el motivo y fecha, sin alterar silenciosamente las transacciones históricas.
- **Consecuencia:** Trazabilidad contable total y sincronización sencilla con la app bancaria.
