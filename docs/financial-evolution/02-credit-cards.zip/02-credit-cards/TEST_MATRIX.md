# MATRIZ DE PRUEBAS AUTOMATIZADAS (T01 - T30) — FASE 2: TARJETAS DE CRÉDITO

Todas las pruebas se ejecutan sobre un motor **SQLite real en memoria (`node:sqlite`)** utilizando las implementaciones de producción de los repositorios y políticas de emisor.

| ID | Nombre de la Prueba | Tipo | Módulo | Resultado |
|---|---|---|---|---|
| **U01** | Ingreso ordinario aumenta activos, caja y patrimonio | Unit | `financialCore` | ✅ PASS |
| **U02** | Gasto ordinario genera consumo, salida de caja y reduce patrimonio | Unit | `financialCore` | ✅ PASS |
| **U03** | Pago de tarjeta NO genera consumo patrimonial (es transferencia de activo a pasivo) | Unit | `financialCore` | ✅ PASS |
| **T01** | Compra antes de corte entra al ciclo actual | Integration | `CycleRepository` | ✅ PASS |
| **T02** | Compra después de corte entra al siguiente ciclo | Integration | `CycleRepository` | ✅ PASS |
| **T03** | Manejo de corte día 31 en febrero / meses cortos | Integration | `CycleRepository` | ✅ PASS |
| **T04** | Creación de extracto snapshot inmutable | Integration | `StatementRepository` | ✅ PASS |
| **T05** | Compras posteriores a la creación de extracto no alteran el extracto anterior | Integration | `StatementRepository` | ✅ PASS |
| **T06** | Pago parcial de tarjeta actualiza extracto y deuda proporcionalmente | Integration | `CardRepository` | ✅ PASS |
| **T07** | Pago mínimo exacto transiciona estado a MINIMUM_COVERED | Integration | `CardRepository` | ✅ PASS |
| **T08** | Pago superior al mínimo e inferior al total del extracto | Integration | `CardRepository` | ✅ PASS |
| **T09** | Pago total del extracto transiciona estado a PAID | Integration | `CardRepository` | ✅ PASS |
| **T10** | Pago total de deuda cancela saldo facturado y no facturado | Integration | `CardRepository` | ✅ PASS |
| **T11** | Pago con intereses + capital libera únicamente la fracción de capital en el cupo disponible | Policy | `NuPolicy` | ✅ PASS |
| **T12** | Reversión (DELETE) de pago de tarjeta restaura exactamente cupo, saldo y estado del extracto | Integration | `TransactionRepository` | ✅ PASS |
| **T13** | Nu Policy aplica orden: impuestos -> cargos -> mora -> corriente -> capital | Policy | `NuPolicy` | ✅ PASS |
| **T14** | RappiCard Policy aplica orden de pago mínimo | Policy | `RappiCardPolicy` | ✅ PASS |
| **T15** | RappiCard Policy aplica excedente sobre el mínimo 100% a capital | Policy | `RappiCardPolicy` | ✅ PASS |
| **T16** | Bancolombia Policy establece supportsDirectedPayment = false | Policy | `BancolombiaPolicy` | ✅ PASS |
| **T17** | Intento de pago dirigido en Bancolombia es rechazado por la política | Policy | `BancolombiaPolicy` | ✅ PASS |
| **T18** | Conciliación sin diferencia confirma consistencia perfecta | Integration | `ReconciliationRepository` | ✅ PASS |
| **T19** | Conciliación con diferencia detecta discrepancia exacta con el banco | Integration | `ReconciliationRepository` | ✅ PASS |
| **T20** | Ajuste de conciliación genera transacción de auditoría sin alterar transacciones pasadas | Integration | `ReconciliationRepository` | ✅ PASS |
| **T21** | Migración de tarjeta existente preserva compras, cuotas y cupos sin pérdida de datos | Integration | `CardRepository` | ✅ PASS |
| **T22** | Pago de tarjeta no duplica consumo patrimonial (mantiene principios contables de Fase 1) | Integration | `CardRepository` | ✅ PASS |
| **T23** | Pago mínimo cubierto -> Estado MINIMUM_COVERED | Integration | `StatementRepository` | ✅ PASS |
| **T24** | Extracto totalmente cubierto -> Estado PAID | Integration | `StatementRepository` | ✅ PASS |
| **T25** | Fecha límite vencida con saldo mínimo pendiente -> Estado OVERDUE | Integration | `StatementRepository` | ✅ PASS |
| **T26** | Rechazo de extracto duplicado para el mismo ciclo | Integration | `StatementRepository` | ✅ PASS |
| **T27** | Rechazo de pago superior a la deuda actual (bloqueo en ausencia de saldo a favor independiente) | Integration | `CardRepository` | ✅ PASS |
| **T28** | Compra a 1 cuota registrada y facturada correctamente | Integration | `CardRepository` | ✅ PASS |
| **T29** | Compra a múltiples cuotas distribuida en cronograma de amortización | Integration | `CardRepository` | ✅ PASS |
| **T30** | Verificación estricta: Cupo liberado === Capital amortizado aplicado | Policy | `GenericPolicy` | ✅ PASS |

**Resumen:** 34 tests ejecutados, 34 pasados (100%), 0 fallos.
