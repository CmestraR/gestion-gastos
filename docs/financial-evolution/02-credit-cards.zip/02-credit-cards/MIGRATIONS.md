# PLAN Y ESPECIFICACIÓN DE MIGRACIONES — FASE 2: TARJETAS DE CRÉDITO

## 1. Tablas Nuevas Creadas (Idempotentes)

```sql
CREATE TABLE IF NOT EXISTS card_billing_cycles (
  id TEXT PRIMARY KEY,
  card_id TEXT NOT NULL,
  cycle_number INTEGER NOT NULL DEFAULT 1,
  start_date TEXT NOT NULL,
  cut_off_date TEXT NOT NULL,
  payment_due_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL,
  FOREIGN KEY (card_id) REFERENCES credit_cards (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS card_statements (
  id TEXT PRIMARY KEY,
  card_id TEXT NOT NULL,
  billing_cycle_id TEXT NOT NULL,
  statement_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  opening_balance REAL NOT NULL DEFAULT 0,
  purchases_total REAL NOT NULL DEFAULT 0,
  advances_total REAL NOT NULL DEFAULT 0,
  principal_total REAL NOT NULL DEFAULT 0,
  current_interest REAL NOT NULL DEFAULT 0,
  late_interest REAL NOT NULL DEFAULT 0,
  handling_fee REAL NOT NULL DEFAULT 0,
  taxes_and_fees REAL NOT NULL DEFAULT 0,
  total_statement_balance REAL NOT NULL DEFAULT 0,
  minimum_payment_original REAL NOT NULL DEFAULT 0,
  statement_balance_paid REAL NOT NULL DEFAULT 0,
  minimum_payment_paid REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  is_manual_snapshot INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (card_id) REFERENCES credit_cards (id) ON DELETE CASCADE,
  FOREIGN KEY (billing_cycle_id) REFERENCES card_billing_cycles (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS card_payment_allocations (
  id TEXT PRIMARY KEY,
  transaction_id TEXT NOT NULL,
  card_id TEXT NOT NULL,
  statement_id TEXT,
  total_payment REAL NOT NULL DEFAULT 0,
  principal_applied REAL NOT NULL DEFAULT 0,
  current_interest_applied REAL NOT NULL DEFAULT 0,
  late_interest_applied REAL NOT NULL DEFAULT 0,
  handling_fee_applied REAL NOT NULL DEFAULT 0,
  taxes_and_fees_applied REAL NOT NULL DEFAULT 0,
  credit_balance_applied REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  FOREIGN KEY (transaction_id) REFERENCES transactions (id) ON DELETE CASCADE,
  FOREIGN KEY (card_id) REFERENCES credit_cards (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS card_reconciliations (
  id TEXT PRIMARY KEY,
  card_id TEXT NOT NULL,
  statement_id TEXT,
  reconciliation_date TEXT NOT NULL,
  app_calculated_debt REAL NOT NULL DEFAULT 0,
  bank_reported_debt REAL NOT NULL DEFAULT 0,
  difference_amount REAL NOT NULL DEFAULT 0,
  adjustment_transaction_id TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (card_id) REFERENCES credit_cards (id) ON DELETE CASCADE
);
```

## 2. Columnas Agregadas mediante ALTER TABLE Seguros

```sql
ALTER TABLE credit_cards ADD COLUMN issuer_id TEXT NOT NULL DEFAULT 'generic';
ALTER TABLE credit_cards ADD COLUMN late_interest_rate_monthly REAL NOT NULL DEFAULT 0;
ALTER TABLE credit_cards ADD COLUMN positive_balance REAL NOT NULL DEFAULT 0;
ALTER TABLE transactions ADD COLUMN statement_id TEXT;
```

## 3. Índices de Alto Rendimiento Agregados

```sql
CREATE INDEX IF NOT EXISTS idx_card_cycles_card_cutoff ON card_billing_cycles (card_id, cut_off_date);
CREATE INDEX IF NOT EXISTS idx_card_statements_card_cycle ON card_statements (card_id, billing_cycle_id);
CREATE INDEX IF NOT EXISTS idx_card_allocations_tx ON card_payment_allocations (transaction_id);
CREATE INDEX IF NOT EXISTS idx_card_allocations_card ON card_payment_allocations (card_id);
CREATE INDEX IF NOT EXISTS idx_card_reconciliations_card ON card_reconciliations (card_id);
CREATE INDEX IF NOT EXISTS idx_transactions_statement ON transactions (statement_id);
```

## 4. Retrocompatibilidad y Preservación de Datos
- Todas las tarjetas existentes conservan sus registros intactos y adquieren por defecto `issuer_id = 'generic'`.
- Todas las compras activas y cuotas históricas quedan asociadas directamente a los ciclos generados por `CycleRepository`.
- No hay pérdida de datos ni conversiones destructivas de columnas.
