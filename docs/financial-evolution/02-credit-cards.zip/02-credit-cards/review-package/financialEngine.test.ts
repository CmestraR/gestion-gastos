import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert';
import { DatabaseSync } from 'node:sqlite';

import {
  evaluateTransactionEffects,
  calculateMonthlyConsumption,
  calculateMonthlyCashFlow,
  calculateConsolidatedNetWorth,
  calculateAccountCashMovement,
} from '../src/utils/financialCore.ts';

import {
  calculateMonthlyQuota,
  generateAmortizationSchedule,
  calculateCardCycleDates,
  convertEAToEM,
  calculateCardStatement,
} from '../src/utils/financialMath.ts';

import { setTestDatabase, initDatabase } from '../src/database/database.ts';
import { AccountRepository } from '../src/database/repositories/accountRepository.ts';
import { CardRepository } from '../src/database/repositories/cardRepository.ts';
import { TransactionRepository } from '../src/database/repositories/transactionRepository.ts';
import { CycleRepository } from '../src/database/repositories/cycleRepository.ts';
import { StatementRepository } from '../src/database/repositories/statementRepository.ts';
import { ReconciliationRepository } from '../src/database/repositories/reconciliationRepository.ts';
import {
  NuPolicy,
  BancolombiaPolicy,
  RappiCardPolicy,
  GenericPolicy,
  getIssuerPolicy,
} from '../src/utils/issuerPolicies/index.ts';

import type {
  Account,
  CreditCard,
  Transaction,
  CardPurchase,
  CardInstallment,
  CardStatement,
} from '../src/types/finance.ts';

/**
 * ADAPTADOR SQLITE REAL PARA PRUEBAS EN NODE.JS
 */
function createRealSqliteDb() {
  const syncDb = new DatabaseSync(':memory:');
  syncDb.exec('PRAGMA foreign_keys = ON;');

  const db = {
    async execAsync(source: string): Promise<void> {
      syncDb.exec(source);
    },
    async runAsync(source: string, params: any[] = []): Promise<{ lastInsertRowId: number; changes: number }> {
      const stmt = syncDb.prepare(source);
      const result = stmt.run(...params);
      return { lastInsertRowId: Number(result.lastInsertRowid), changes: Number(result.changes) };
    },
    async getAllAsync<T>(source: string, params: any[] = []): Promise<T[]> {
      const stmt = syncDb.prepare(source);
      return stmt.all(...params) as T[];
    },
    async getFirstAsync<T>(source: string, params: any[] = []): Promise<T | null> {
      const stmt = syncDb.prepare(source);
      const row = stmt.get(...params);
      return (row as T) || null;
    },
    async withTransactionAsync<T>(action: () => Promise<T>): Promise<T> {
      syncDb.exec('BEGIN TRANSACTION;');
      try {
        const result = await action();
        syncDb.exec('COMMIT;');
        return result;
      } catch (err) {
        syncDb.exec('ROLLBACK;');
        throw err;
      }
    },
  };

  return { db, syncDb };
}

async function setupTestDatabase() {
  const testDb = createRealSqliteDb();
  await initDatabase(testDb.db);
  return testDb;
}

describe('BATERÍA COMPLETA DE PRUEBAS — MOTOR FINANCIERO Y TARJETAS DE CRÉDITO (FASE 2)', () => {
  // ==========================================
  // BLOQUE 1: PRUEBAS UNITARIAS [UNIT] (Fase 1 Base)
  // ==========================================
  describe('1. Pruebas Unitarias [UNIT] - Lógica y Matemática Pura', () => {
    test('U01. Ingreso ordinario aumenta activos, caja y patrimonio', () => {
      const tx: Transaction = {
        id: 'tx-inc-1',
        accountId: 'acc-bancolombia',
        type: 'income',
        amount: 1000000,
        categoryId: 'cat-salary',
        description: 'Nómina',
        date: '2026-08-15',
        createdAt: '2026-08-15',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0);
      assert.strictEqual(effects.cashInflow, 1000000);
      assert.strictEqual(effects.cashOutflow, 0);
      assert.strictEqual(effects.assetDelta, 1000000);
      assert.strictEqual(effects.liabilityDelta, 0);
      assert.strictEqual(effects.netWorthDelta, 1000000);
    });

    test('U02. Gasto ordinario genera consumo, salida de caja y reduce patrimonio', () => {
      const tx: Transaction = {
        id: 'tx-exp-1',
        accountId: 'acc-bancolombia',
        type: 'expense',
        amount: 150000,
        categoryId: 'cat-groceries',
        description: 'Supermercado',
        date: '2026-08-16',
        createdAt: '2026-08-16',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 150000);
      assert.strictEqual(effects.cashInflow, 0);
      assert.strictEqual(effects.cashOutflow, 150000);
      assert.strictEqual(effects.assetDelta, -150000);
      assert.strictEqual(effects.liabilityDelta, 0);
      assert.strictEqual(effects.netWorthDelta, -150000);
    });

    test('U03. Pago de tarjeta NO genera consumo patrimonial (es transferencia de activo a pasivo)', () => {
      const tx: Transaction = {
        id: 'tx-pay-1',
        accountId: 'acc-bancolombia',
        cardId: 'card-nu',
        type: 'card_payment',
        amount: 250000,
        categoryId: 'cat-financial',
        description: 'Pago Tarjeta Nu',
        date: '2026-08-18',
        createdAt: '2026-08-18',
      };

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0, 'No debe considerarse consumo del mes');
      assert.strictEqual(effects.cashOutflow, 250000, 'Es una salida de caja bancaria');
      assert.strictEqual(effects.assetDelta, -250000, 'Reduce el activo líquido');
      assert.strictEqual(effects.liabilityDelta, -250000, 'Reduce el pasivo de la tarjeta');
      assert.strictEqual(effects.netWorthDelta, 0, 'El patrimonio neto permanece neutro');
    });
  });

  // =========================================================================
  // BLOQUE 2: BATERÍA COMPLETA FASE 2 (T01 a T30) SOBRE SQLITE REAL Y POLÍTICAS
  // =========================================================================
  describe('2. Batería Completa de Tarjetas de Crédito (T01 a T30) en SQLite Real', () => {
    let testDb: ReturnType<typeof createRealSqliteDb>;

    beforeEach(async () => {
      testDb = await setupTestDatabase();
      setTestDatabase(testDb.db);

      // Crear cuenta y tarjetas base
      await AccountRepository.create({
        id: 'acc-1',
        name: 'Ahorros Bancolombia',
        type: 'savings',
        bankName: 'Bancolombia',
        balance: 3000000,
        initialBalance: 3000000,
        currency: 'COP',
        color: '#10B981',
        icon: 'Wallet',
        includeInTotal: true,
        isArchived: false,
        createdAt: '2026-08-01',
      });

      // Tarjeta Nu
      await CardRepository.create({
        id: 'card-nu',
        name: 'Nu Card',
        bankName: 'Nu Colombia',
        cardBrand: 'mastercard',
        issuerId: 'nu',
        creditLimit: 5000000,
        availableLimit: 5000000,
        cutOffDay: 15,
        paymentDueDay: 5,
        interestRateMonthly: 2.1,
        handlingFee: 0,
        colorGradient: ['#820AD1', '#4C0677'],
        currency: 'COP',
        isArchived: false,
        createdAt: '2026-08-01',
      });

      // Tarjeta Bancolombia
      await CardRepository.create({
        id: 'card-bancolombia',
        name: 'Bancolombia Visa',
        bankName: 'Bancolombia',
        cardBrand: 'visa',
        issuerId: 'bancolombia',
        creditLimit: 10000000,
        availableLimit: 10000000,
        cutOffDay: 20,
        paymentDueDay: 10,
        interestRateMonthly: 2.3,
        handlingFee: 25000,
        colorGradient: ['#FDDA24', '#000000'],
        currency: 'COP',
        isArchived: false,
        createdAt: '2026-08-01',
      });

      // Tarjeta RappiCard
      await CardRepository.create({
        id: 'card-rappi',
        name: 'RappiCard',
        bankName: 'RappiCard',
        cardBrand: 'visa',
        issuerId: 'rappicard',
        creditLimit: 4000000,
        availableLimit: 4000000,
        cutOffDay: 28,
        paymentDueDay: 10,
        interestRateMonthly: 2.2,
        handlingFee: 0,
        colorGradient: ['#FF441F', '#B32400'],
        currency: 'COP',
        isArchived: false,
        createdAt: '2026-08-01',
      });
    });

    test('T01: Compra antes de corte entra al ciclo actual', async () => {
      // Corte día 15 de agosto
      const cycle = await CycleRepository.getCycleForPurchaseDate('card-nu', '2026-08-10');
      assert.strictEqual(cycle.cutOffDate, '2026-08-15');
      assert.strictEqual(cycle.paymentDueDate, '2026-09-05');
    });

    test('T02: Compra después de corte entra al siguiente ciclo', async () => {
      // Compra el 18 de agosto (post-corte del día 15)
      const cycle = await CycleRepository.getCycleForPurchaseDate('card-nu', '2026-08-18');
      assert.strictEqual(cycle.cutOffDate, '2026-09-15');
      assert.strictEqual(cycle.paymentDueDate, '2026-10-05');
    });

    test('T03: Manejo de corte día 31 en febrero / meses cortos', async () => {
      // Tarjeta con corte día 31
      await CardRepository.create({
        id: 'card-endmonth',
        name: 'Fin de Mes Card',
        bankName: 'Banco',
        cardBrand: 'visa',
        issuerId: 'generic',
        creditLimit: 2000000,
        availableLimit: 2000000,
        cutOffDay: 31,
        paymentDueDay: 15,
        interestRateMonthly: 2.0,
        handlingFee: 0,
        colorGradient: ['#000', '#111'],
        currency: 'COP',
        isArchived: false,
        createdAt: '2026-02-01',
      });

      // Febrero 2026 tiene 28 días
      const febCycle = await CycleRepository.getOrCreateCurrentCycle('card-endmonth', new Date(2026, 1, 10));
      assert.strictEqual(febCycle.cutOffDate, '2026-02-28', 'Debe clampear al 28 en febrero 2026');

      // Abril tiene 30 días
      const aprCycle = await CycleRepository.getOrCreateCurrentCycle('card-endmonth', new Date(2026, 3, 10));
      assert.strictEqual(aprCycle.cutOffDate, '2026-04-30', 'Debe clampear al 30 en abril');
    });

    test('T04: Creación de extracto snapshot inmutable', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));

      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 450000,
        currentInterest: 50000,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      assert.strictEqual(stmt.totalStatementBalance, 500000);
      assert.strictEqual(stmt.minimumPaymentOriginal, 100000);
      assert.strictEqual(stmt.status, 'open');

      const retrieved = await StatementRepository.getLatestStatement('card-nu');
      assert.strictEqual(retrieved?.id, stmt.id);
      assert.strictEqual(retrieved?.totalStatementBalance, 500000);
    });

    test('T05: Compras posteriores a la creación de extracto no alteran el extracto anterior', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 400000,
        advancesTotal: 0,
        principalTotal: 400000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 400000,
        minimumPaymentOriginal: 80000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      // Nueva compra el 20 de agosto (post-corte)
      await CardRepository.createPurchaseAtomic(
        {
          id: 'purch-post-cut',
          cardId: 'card-nu',
          description: 'Zapatos',
          categoryId: 'cat-shopping',
          amount: 250000,
          installmentsTotal: 1,
          installmentsPaid: 0,
          monthlyInstallmentAmount: 250000,
          interestRateMonthly: 0,
          firstInstallmentDate: '2026-09-20',
          status: 'active',
          createdAt: '2026-08-20',
        },
        [
          {
            id: 'inst-post-1',
            purchaseId: 'purch-post-cut',
            installmentNumber: 1,
            dueDate: '2026-09-20',
            principalAmount: 250000,
            interestAmount: 0,
            totalAmount: 250000,
            isPaid: false,
          },
        ]
      );

      // El extracto del 15 de agosto debe permanecer intacto con 400.000
      const stmt = await StatementRepository.getLatestStatement('card-nu');
      assert.strictEqual(stmt?.totalStatementBalance, 400000);
      assert.strictEqual(stmt?.minimumPaymentOriginal, 80000);

      // Y el summary debe reflejar los 3 saldos correctamente:
      const summary = await CardRepository.getCardStatementSummary((await CardRepository.getById('card-nu'))!);
      assert.strictEqual(summary.totalCurrentDebt, 250000);
      assert.strictEqual(summary.billedStatementDebtRemaining, 400000);
    });

    test('T06: Pago parcial de tarjeta actualiza extracto y deuda proporcionalmente', async () => {
      // Simular consumo de cupo
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      // Pago parcial de $50.000 (menor al mínimo)
      await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 50000, stmt.id);

      const updatedStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updatedStmt?.statementBalancePaid, 50000);
      assert.strictEqual(updatedStmt?.minimumPaymentPaid, 50000);
      assert.strictEqual(updatedStmt?.status, 'partially_paid');

      const card = await CardRepository.getById('card-nu');
      assert.strictEqual(card?.availableLimit, 4550000);
    });

    test('T07: Pago mínimo exacto transiciona estado a MINIMUM_COVERED', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 100000, stmt.id);

      const updatedStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updatedStmt?.status, 'minimum_covered');
    });

    test('T08: Pago superior al mínimo e inferior al total del extracto', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 250000, stmt.id);

      const updatedStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updatedStmt?.status, 'minimum_covered');
      assert.strictEqual(updatedStmt?.statementBalancePaid, 250000);
    });

    test('T09: Pago total del extracto transiciona estado a PAID', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 500000, stmt.id);

      const updatedStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updatedStmt?.status, 'paid');
      assert.strictEqual(updatedStmt?.statementBalancePaid, 500000);

      const card = await CardRepository.getById('card-nu');
      assert.strictEqual(card?.availableLimit, 5000000);
    });

    test('T10: Pago total de deuda cancela saldo facturado y no facturado', async () => {
      // Tarjeta con cupo usado de 800.000 (500.000 facturados + 300.000 post-corte)
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4200000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      // Pago total de la deuda (800.000)
      await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 800000, stmt.id);

      const card = await CardRepository.getById('card-nu');
      assert.strictEqual(card?.availableLimit, 5000000, 'Cupo 100% restaurado');

      const updatedStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updatedStmt?.status, 'paid');
    });

    test('T11: Pago con intereses + capital libera únicamente la fracción de capital en el cupo disponible', async () => {
      const nuPolicy = new NuPolicy();
      const result = nuPolicy.allocatePayment(150000, {
        creditLimit: 5000000,
        availableLimit: 4000000, // Deuda = 1.000.000
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 10000,
        handlingFee: 15000,
        lateInterest: 5000,
        currentInterest: 20000,
        principalTotal: 450000,
        unbilledDebt: 0,
      });

      // Total cargos no capital = 10k + 15k + 5k + 20k = 50.000
      // Capital aplicado = 150.000 - 50.000 = 100.000
      assert.strictEqual(result.taxesAndFeesApplied, 10000);
      assert.strictEqual(result.handlingFeeApplied, 15000);
      assert.strictEqual(result.lateInterestApplied, 5000);
      assert.strictEqual(result.currentInterestApplied, 20000);
      assert.strictEqual(result.principalApplied, 100000);
      assert.strictEqual(result.resultingAvailableLimit, 4100000, 'Solo el capital debe sumarse al cupo');
    });

    test('T12: Reversión (DELETE) de pago de tarjeta restaura exactamente cupo, saldo y estado del extracto', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      // 1. Realizar pago
      const alloc = await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 200000, stmt.id);

      let card = await CardRepository.getById('card-nu');
      let acc = (await AccountRepository.getAll()).find((a) => a.id === 'acc-1');
      assert.strictEqual(card?.availableLimit, 4700000);
      assert.strictEqual(acc?.balance, 2800000);

      // 2. Revertir transacción eliminándola
      await TransactionRepository.delete(alloc.transactionId);

      card = await CardRepository.getById('card-nu');
      acc = (await AccountRepository.getAll()).find((a) => a.id === 'acc-1');
      assert.strictEqual(card?.availableLimit, 4500000, 'Cupo revertido');
      assert.strictEqual(acc?.balance, 3000000, 'Saldo bancario devuelto');

      const restoredStmt = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(restoredStmt?.statementBalancePaid, 0, 'Extracto saldo revertido');
      assert.strictEqual(restoredStmt?.status, 'open', 'Estado revertido a open');
    });

    test('T13: Nu Policy aplica orden: impuestos -> cargos -> mora -> corriente -> capital', () => {
      const nuPolicy = new NuPolicy();
      const res = nuPolicy.allocatePayment(60000, {
        creditLimit: 5000000,
        availableLimit: 4000000,
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 10000,
        handlingFee: 15000,
        lateInterest: 10000,
        currentInterest: 15000,
        principalTotal: 450000,
        unbilledDebt: 0,
      });

      // $60.000 cubre: $10k tax + $15k handling + $10k late + $15k current ($50k) + $10k capital
      assert.strictEqual(res.taxesAndFeesApplied, 10000);
      assert.strictEqual(res.handlingFeeApplied, 15000);
      assert.strictEqual(res.lateInterestApplied, 10000);
      assert.strictEqual(res.currentInterestApplied, 15000);
      assert.strictEqual(res.principalApplied, 10000);
    });

    test('T14: RappiCard Policy aplica orden de pago mínimo', () => {
      const rappiPolicy = new RappiCardPolicy();
      const res = rappiPolicy.allocatePayment(50000, {
        creditLimit: 4000000,
        availableLimit: 3500000,
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 5000,
        handlingFee: 0,
        lateInterest: 10000,
        currentInterest: 20000,
        principalTotal: 465000,
        unbilledDebt: 0,
      });

      // $50.000 cubre: $10k late + $20k current + $5k tax ($35k) + $15k capital
      assert.strictEqual(res.lateInterestApplied, 10000);
      assert.strictEqual(res.currentInterestApplied, 20000);
      assert.strictEqual(res.taxesAndFeesApplied, 5000);
      assert.strictEqual(res.principalApplied, 15000);
    });

    test('T15: RappiCard Policy aplica excedente sobre el mínimo 100% a capital', () => {
      const rappiPolicy = new RappiCardPolicy();
      const res = rappiPolicy.allocatePayment(300000, {
        creditLimit: 4000000,
        availableLimit: 3500000,
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 0,
        handlingFee: 0,
        lateInterest: 0,
        currentInterest: 30000,
        principalTotal: 470000,
        unbilledDebt: 0,
      });

      // Cubre $30.000 de interés y los $270.000 restantes van 100% a capital
      assert.strictEqual(res.currentInterestApplied, 30000);
      assert.strictEqual(res.principalApplied, 270000);
    });

    test('T16: Bancolombia Policy establece supportsDirectedPayment = false', () => {
      const policy = new BancolombiaPolicy();
      assert.strictEqual(policy.supportsDirectedPayment, false);
    });

    test('T17: Intento de pago dirigido en Bancolombia es rechazado por la política', () => {
      const policy = new BancolombiaPolicy();
      assert.throws(
        () =>
          policy.allocatePayment(
            100000,
            {
              creditLimit: 10000000,
              availableLimit: 9000000,
              totalStatementBalance: 500000,
              statementBalancePaid: 0,
              minimumPaymentOriginal: 100000,
              minimumPaymentPaid: 0,
              taxesAndFees: 0,
              handlingFee: 0,
              lateInterest: 0,
              currentInterest: 0,
              principalTotal: 500000,
              unbilledDebt: 0,
            },
            { isDirected: true, targetPurchaseId: 'purch-1' }
          ),
        /Bancolombia no permite dirigir abonos a compras específicas/
      );
    });

    test('T18: Conciliación sin diferencia confirma consistencia perfecta', async () => {
      // App deuda = 500.000, Banco = 500.000
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);

      await ReconciliationRepository.createReconciliation({
        id: 'rec-perf-1',
        cardId: 'card-nu',
        reconciliationDate: '2026-08-31',
        appCalculatedDebt: 500000,
        bankReportedDebt: 500000,
        differenceAmount: 0,
        createdAt: '2026-08-31',
      });

      const recs = await ReconciliationRepository.getReconciliationsForCard('card-nu');
      assert.strictEqual(recs.length, 1);
      assert.strictEqual(recs[0].differenceAmount, 0);

      // No se generó transacción de ajuste
      const txs = await TransactionRepository.getAll();
      const adjTx = txs.find((t) => t.type === 'balance_adjustment');
      assert.strictEqual(adjTx, undefined);
    });

    test('T19: Conciliación con diferencia detecta discrepancia exacta con el banco', async () => {
      // App deuda = 500.000, Banco = 525.000 (diff = +25.000)
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);

      await ReconciliationRepository.createReconciliation({
        id: 'rec-diff-1',
        cardId: 'card-nu',
        reconciliationDate: '2026-08-31',
        appCalculatedDebt: 500000,
        bankReportedDebt: 525000,
        differenceAmount: 25000,
        notes: 'Seguro de vida debitado por el banco',
        createdAt: '2026-08-31',
      });

      const recs = await ReconciliationRepository.getReconciliationsForCard('card-nu');
      assert.strictEqual(recs.length, 1);
      assert.strictEqual(recs[0].differenceAmount, 25000);
    });

    test('T20: Ajuste de conciliación genera transacción de auditoría sin alterar transacciones pasadas', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);

      await ReconciliationRepository.createReconciliation({
        id: 'rec-diff-2',
        cardId: 'card-nu',
        reconciliationDate: '2026-08-31',
        appCalculatedDebt: 500000,
        bankReportedDebt: 530000,
        differenceAmount: 30000,
        notes: 'Comisión no facturada',
        createdAt: '2026-08-31',
      });

      const txs = await TransactionRepository.getAll();
      const adjTx = txs.find((t) => t.type === 'balance_adjustment');
      assert.ok(adjTx, 'Transacción de ajuste creada');
      assert.strictEqual(adjTx.amount, 30000);
      assert.strictEqual(adjTx.cardId, 'card-nu');

      // Cupo disponible ajustado a 4.470.000
      const card = await CardRepository.getById('card-nu');
      assert.strictEqual(card?.availableLimit, 4470000);
    });

    test('T21: Migración de tarjeta existente preserva compras, cuotas y cupos sin pérdida de datos', async () => {
      // Simular tarjeta existente antes de Fase 2
      const existingCards = await CardRepository.getAll();
      assert.strictEqual(existingCards.length, 3);
      assert.strictEqual(existingCards.find((c) => c.id === 'card-nu')?.issuerId, 'nu');
    });

    test('T22: Pago de tarjeta no duplica consumo patrimonial (mantiene principios contables de Fase 1)', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4500000 WHERE id = ?', ['card-nu']);
      const alloc = await CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 100000);

      const tx = (await TransactionRepository.getAll()).find((t) => t.id === alloc.transactionId);
      assert.ok(tx);

      const effects = evaluateTransactionEffects(tx);
      assert.strictEqual(effects.consumption, 0, 'Consumo debe ser 0');
      assert.strictEqual(effects.netWorthDelta, 0, 'Patrimonio debe ser neutro');
    });

    test('T23: Pago mínimo cubierto -> Estado MINIMUM_COVERED', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await StatementRepository.updateStatementPayment(stmt.id, 100000, 100000);
      const updated = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updated?.status, 'minimum_covered');
    });

    test('T24: Extracto totalmente cubierto -> Estado PAID', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await StatementRepository.updateStatementPayment(stmt.id, 500000, 500000);
      const updated = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updated?.status, 'paid');
    });

    test('T25: Fecha límite vencida con saldo mínimo pendiente -> Estado OVERDUE', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-07-15'));
      const stmt = await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-07-15',
        dueDate: '2026-08-05', // Fecha ya pasada
        openingBalance: 0,
        purchasesTotal: 300000,
        advancesTotal: 0,
        principalTotal: 300000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 300000,
        minimumPaymentOriginal: 60000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await StatementRepository.updateStatementPayment(stmt.id, 0, 0);
      const updated = await StatementRepository.getStatementById(stmt.id);
      assert.strictEqual(updated?.status, 'overdue');
    });

    test('T26: Rechazo de extracto duplicado para el mismo ciclo', async () => {
      const cycle = await CycleRepository.getOrCreateCurrentCycle('card-nu', new Date('2026-08-15'));
      await StatementRepository.createSnapshot({
        cardId: 'card-nu',
        billingCycleId: cycle.id,
        statementDate: '2026-08-15',
        dueDate: '2026-09-05',
        openingBalance: 0,
        purchasesTotal: 500000,
        advancesTotal: 0,
        principalTotal: 500000,
        currentInterest: 0,
        lateInterest: 0,
        handlingFee: 0,
        taxesAndFees: 0,
        totalStatementBalance: 500000,
        minimumPaymentOriginal: 100000,
        statementBalancePaid: 0,
        minimumPaymentPaid: 0,
        status: 'open',
      });

      await assert.rejects(
        () =>
          StatementRepository.createSnapshot({
            cardId: 'card-nu',
            billingCycleId: cycle.id,
            statementDate: '2026-08-15',
            dueDate: '2026-09-05',
            openingBalance: 0,
            purchasesTotal: 500000,
            advancesTotal: 0,
            principalTotal: 500000,
            currentInterest: 0,
            lateInterest: 0,
            handlingFee: 0,
            taxesAndFees: 0,
            totalStatementBalance: 500000,
            minimumPaymentOriginal: 100000,
            statementBalancePaid: 0,
            minimumPaymentPaid: 0,
            status: 'open',
          }),
        /Ya existe un extracto registrado para este ciclo/
      );
    });

    test('T27: Rechazo de pago superior a la deuda actual (bloqueo en ausencia de saldo a favor independiente)', async () => {
      await testDb.db.runAsync('UPDATE credit_cards SET available_limit = 4800000 WHERE id = ?', ['card-nu']); // Deuda = 200.000

      await assert.rejects(
        () => CardRepository.payCreditCardAtomic('card-nu', 'acc-1', 300000),
        /no puede ser superior a la deuda actual/
      );
    });

    test('T28: Compra a 1 cuota registrada y facturada correctamente', async () => {
      await CardRepository.createPurchaseAtomic(
        {
          id: 'purch-1cuota',
          cardId: 'card-nu',
          description: 'Cena Restaurante',
          categoryId: 'cat-food',
          amount: 80000,
          installmentsTotal: 1,
          installmentsPaid: 0,
          monthlyInstallmentAmount: 80000,
          interestRateMonthly: 0,
          firstInstallmentDate: '2026-08-25',
          status: 'active',
          createdAt: '2026-08-25',
        },
        [
          {
            id: 'inst-1cuota-1',
            purchaseId: 'purch-1cuota',
            installmentNumber: 1,
            dueDate: '2026-09-05',
            principalAmount: 80000,
            interestAmount: 0,
            totalAmount: 80000,
            isPaid: false,
          },
        ]
      );

      const card = await CardRepository.getById('card-nu');
      assert.strictEqual(card?.availableLimit, 4920000);

      const insts = await CardRepository.getInstallmentsForPurchase('purch-1cuota');
      assert.strictEqual(insts.length, 1);
      assert.strictEqual(insts[0].principalAmount, 80000);
      assert.strictEqual(insts[0].interestAmount, 0);
    });

    test('T29: Compra a múltiples cuotas distribuida en cronograma de amortización', async () => {
      const schedule = generateAmortizationSchedule('purch-3cuotas', 1200000, 2.0, 3, new Date('2026-09-05'));
      assert.strictEqual(schedule.length, 3);

      await CardRepository.createPurchaseAtomic(
        {
          id: 'purch-3cuotas',
          cardId: 'card-bancolombia',
          description: 'Computador',
          categoryId: 'cat-tech',
          amount: 1200000,
          installmentsTotal: 3,
          installmentsPaid: 0,
          monthlyInstallmentAmount: schedule[0].totalAmount,
          interestRateMonthly: 2.0,
          firstInstallmentDate: '2026-09-05',
          status: 'active',
          createdAt: '2026-08-25',
        },
        schedule.map((s) => ({
          id: `inst-tech-${s.installmentNumber}`,
          purchaseId: 'purch-3cuotas',
          installmentNumber: s.installmentNumber,
          dueDate: s.dueDate,
          principalAmount: s.principalAmount,
          interestAmount: s.interestAmount,
          totalAmount: s.totalAmount,
          isPaid: false,
        }))
      );

      const card = await CardRepository.getById('card-bancolombia');
      assert.strictEqual(card?.availableLimit, 8800000);

      const insts = await CardRepository.getInstallmentsForPurchase('purch-3cuotas');
      assert.strictEqual(insts.length, 3);
      assert.strictEqual(insts[0].isPaid, false);
    });

    test('T30: Verificación estricta: Cupo liberado === Capital amortizado aplicado', async () => {
      const genericPolicy = new GenericPolicy();
      const res = genericPolicy.allocatePayment(100000, {
        creditLimit: 5000000,
        availableLimit: 4000000,
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 0,
        handlingFee: 0,
        lateInterest: 0,
        currentInterest: 25000,
        principalTotal: 475000,
        unbilledDebt: 0,
      });

      // Liberación de cupo debe ser estrictamente 75.000 (100.000 - 25.000)
      const cupoDelta = res.resultingAvailableLimit - 4000000;
      assert.strictEqual(cupoDelta, res.principalApplied);
      assert.strictEqual(cupoDelta, 75000);
    });

    test('T30: Verificación estricta: Cupo liberado === Capital amortizado aplicado', async () => {
      const genericPolicy = new GenericPolicy();
      const res = genericPolicy.allocatePayment(100000, {
        creditLimit: 5000000,
        availableLimit: 4000000,
        totalStatementBalance: 500000,
        statementBalancePaid: 0,
        minimumPaymentOriginal: 100000,
        minimumPaymentPaid: 0,
        taxesAndFees: 0,
        handlingFee: 0,
        lateInterest: 0,
        currentInterest: 25000,
        principalTotal: 475000,
        unbilledDebt: 0,
      });

      // Liberación de cupo debe ser estrictamente 75.000 (100.000 - 25.000)
      const cupoDelta = res.resultingAvailableLimit - 4000000;
      assert.strictEqual(cupoDelta, res.principalApplied);
      assert.strictEqual(cupoDelta, 75000);
    });
  });
});
