import { getDatabase } from '../database.ts';
import type { CardStatement, StatementStatus } from '../../types/finance.ts';

export const StatementRepository = {
  /**
   * Crea un Snapshot Inmutable de Extracto.
   * Rechaza extractos duplicados para el mismo ciclo.
   */
  async createSnapshot(
    data: Omit<CardStatement, 'id' | 'createdAt'>
  ): Promise<CardStatement> {
    const db = await getDatabase();
    const now = new Date().toISOString();
    const statementId = `stmt-${data.cardId}-${data.billingCycleId}`;

    // Validar que no exista un extracto ya registrado para este ciclo
    const existing = await db.getFirstAsync<{ id: string }>(
      'SELECT id FROM card_statements WHERE card_id = ? AND billing_cycle_id = ?',
      [data.cardId, data.billingCycleId]
    );

    if (existing) {
      throw new Error('Ya existe un extracto registrado para este ciclo de facturación.');
    }

    await db.runAsync(
      `INSERT INTO card_statements (
        id, card_id, billing_cycle_id, statement_date, due_date, opening_balance,
        purchases_total, advances_total, principal_total, current_interest, late_interest,
        handling_fee, taxes_and_fees, total_statement_balance, minimum_payment_original,
        statement_balance_paid, minimum_payment_paid, status, is_manual_snapshot, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        statementId,
        data.cardId,
        data.billingCycleId,
        data.statementDate,
        data.dueDate,
        data.openingBalance,
        data.purchasesTotal,
        data.advancesTotal,
        data.principalTotal,
        data.currentInterest,
        data.lateInterest,
        data.handlingFee,
        data.taxesAndFees,
        data.totalStatementBalance,
        data.minimumPaymentOriginal,
        data.statementBalancePaid || 0,
        data.minimumPaymentPaid || 0,
        data.status || 'open',
        data.isManualSnapshot ? 1 : 0,
        data.notes || null,
        now,
      ]
    );

    return {
      ...data,
      id: statementId,
      createdAt: now,
    };
  },

  /**
   * Registra un extracto manual o saldo de apertura histórico
   */
  async createManualStatement(stmt: CardStatement): Promise<void> {
    const db = await getDatabase();
    const now = new Date().toISOString();

    const existing = await db.getFirstAsync<{ id: string }>(
      'SELECT id FROM card_statements WHERE id = ?',
      [stmt.id]
    );

    if (existing) {
      throw new Error(`Ya existe un extracto con el ID ${stmt.id}.`);
    }

    await db.runAsync(
      `INSERT INTO card_statements (
        id, card_id, billing_cycle_id, statement_date, due_date, opening_balance,
        purchases_total, advances_total, principal_total, current_interest, late_interest,
        handling_fee, taxes_and_fees, total_statement_balance, minimum_payment_original,
        statement_balance_paid, minimum_payment_paid, status, is_manual_snapshot, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        stmt.id,
        stmt.cardId,
        stmt.billingCycleId,
        stmt.statementDate,
        stmt.dueDate,
        stmt.openingBalance,
        stmt.purchasesTotal,
        stmt.advancesTotal,
        stmt.principalTotal,
        stmt.currentInterest,
        stmt.lateInterest,
        stmt.handlingFee,
        stmt.taxesAndFees,
        stmt.totalStatementBalance,
        stmt.minimumPaymentOriginal,
        stmt.statementBalancePaid,
        stmt.minimumPaymentPaid,
        stmt.status,
        1, // is_manual_snapshot
        stmt.notes || null,
        stmt.createdAt || now,
      ]
    );
  },

  /**
   * Obtiene el extracto más reciente de una tarjeta
   */
  async getLatestStatement(cardId: string): Promise<CardStatement | null> {
    const db = await getDatabase();
    const row = await db.getFirstAsync<{
      id: string;
      card_id: string;
      billing_cycle_id: string;
      statement_date: string;
      due_date: string;
      opening_balance: number;
      purchases_total: number;
      advances_total: number;
      principal_total: number;
      current_interest: number;
      late_interest: number;
      handling_fee: number;
      taxes_and_fees: number;
      total_statement_balance: number;
      minimum_payment_original: number;
      statement_balance_paid: number;
      minimum_payment_paid: number;
      status: StatementStatus;
      is_manual_snapshot: number;
      notes: string | null;
      created_at: string;
    }>(
      'SELECT * FROM card_statements WHERE card_id = ? ORDER BY statement_date DESC, created_at DESC LIMIT 1',
      [cardId]
    );

    if (!row) return null;

    return {
      id: row.id,
      cardId: row.card_id,
      billingCycleId: row.billing_cycle_id,
      statementDate: row.statement_date,
      dueDate: row.due_date,
      openingBalance: row.opening_balance,
      purchasesTotal: row.purchases_total,
      advancesTotal: row.advances_total,
      principalTotal: row.principal_total,
      currentInterest: row.current_interest,
      lateInterest: row.late_interest,
      handlingFee: row.handling_fee,
      taxesAndFees: row.taxes_and_fees,
      totalStatementBalance: row.total_statement_balance,
      minimumPaymentOriginal: row.minimum_payment_original,
      statementBalancePaid: row.statement_balance_paid,
      minimumPaymentPaid: row.minimum_payment_paid,
      status: row.status,
      isManualSnapshot: row.is_manual_snapshot === 1,
      notes: row.notes || undefined,
      createdAt: row.created_at,
    };
  },

  /**
   * Obtiene un extracto por su ID
   */
  async getStatementById(id: string): Promise<CardStatement | null> {
    const db = await getDatabase();
    const row = await db.getFirstAsync<any>(
      'SELECT * FROM card_statements WHERE id = ?',
      [id]
    );

    if (!row) return null;

    return {
      id: row.id,
      cardId: row.card_id,
      billingCycleId: row.billing_cycle_id,
      statementDate: row.statement_date,
      dueDate: row.due_date,
      openingBalance: row.opening_balance,
      purchasesTotal: row.purchases_total,
      advancesTotal: row.advances_total,
      principalTotal: row.principal_total,
      currentInterest: row.current_interest,
      lateInterest: row.late_interest,
      handlingFee: row.handling_fee,
      taxesAndFees: row.taxes_and_fees,
      totalStatementBalance: row.total_statement_balance,
      minimumPaymentOriginal: row.minimum_payment_original,
      statementBalancePaid: row.statement_balance_paid,
      minimumPaymentPaid: row.minimum_payment_paid,
      status: row.status,
      isManualSnapshot: row.is_manual_snapshot === 1,
      notes: row.notes || undefined,
      createdAt: row.created_at,
    };
  },

  /**
   * Obtiene todos los extractos de una tarjeta ordenados por fecha descendente
   */
  async getStatementsForCard(cardId: string): Promise<CardStatement[]> {
    const db = await getDatabase();
    const rows = await db.getAllAsync<any>(
      'SELECT * FROM card_statements WHERE card_id = ? ORDER BY statement_date DESC',
      [cardId]
    );

    return rows.map((row) => ({
      id: row.id,
      cardId: row.card_id,
      billingCycleId: row.billing_cycle_id,
      statementDate: row.statement_date,
      dueDate: row.due_date,
      openingBalance: row.opening_balance,
      purchasesTotal: row.purchases_total,
      advancesTotal: row.advances_total,
      principalTotal: row.principal_total,
      currentInterest: row.current_interest,
      lateInterest: row.late_interest,
      handlingFee: row.handling_fee,
      taxesAndFees: row.taxes_and_fees,
      totalStatementBalance: row.total_statement_balance,
      minimumPaymentOriginal: row.minimum_payment_original,
      statementBalancePaid: row.statement_balance_paid,
      minimumPaymentPaid: row.minimum_payment_paid,
      status: row.status,
      isManualSnapshot: row.is_manual_snapshot === 1,
      notes: row.notes || undefined,
      createdAt: row.created_at,
    }));
  },

  /**
   * Actualiza el saldo pagado hacia un extracto y reevalúa su estado
   */
  async updateStatementPayment(
    statementId: string,
    paymentDelta: number,
    minimumPaymentDelta: number
  ): Promise<void> {
    const db = await getDatabase();
    const stmt = await this.getStatementById(statementId);
    if (!stmt) return;

    const newStatementPaid = Math.max(0, +(stmt.statementBalancePaid + paymentDelta).toFixed(2));
    const newMinimumPaid = Math.max(0, +(stmt.minimumPaymentPaid + minimumPaymentDelta).toFixed(2));

    // Determinar nuevo estado
    let newStatus: StatementStatus = 'open';
    if (newStatementPaid >= stmt.totalStatementBalance) {
      newStatus = 'paid';
    } else if (newMinimumPaid >= stmt.minimumPaymentOriginal) {
      newStatus = 'minimum_covered';
    } else if (newStatementPaid > 0) {
      newStatus = 'partially_paid';
    }

    // Verificar si está vencido
    const today = new Date().toISOString().split('T')[0];
    if (today > stmt.dueDate && newStatus !== 'paid' && newStatus !== 'minimum_covered') {
      newStatus = 'overdue';
    }

    await db.runAsync(
      `UPDATE card_statements 
       SET statement_balance_paid = ?,
           minimum_payment_paid = ?,
           status = ?
       WHERE id = ?`,
      [newStatementPaid, newMinimumPaid, newStatus, statementId]
    );
  },
};
