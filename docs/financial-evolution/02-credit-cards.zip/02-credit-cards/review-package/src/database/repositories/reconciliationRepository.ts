import { getDatabase } from '../database.ts';
import type { CardReconciliation } from '../../types/finance.ts';
import { TransactionRepository } from './transactionRepository.ts';

export const ReconciliationRepository = {
  /**
   * Registra una conciliación de tarjeta y opcionalmente un movimiento de ajuste auditado
   */
  async createReconciliation(rec: CardReconciliation): Promise<void> {
    const db = await getDatabase();
    const now = new Date().toISOString();

    await db.withTransactionAsync(async () => {
      // 1. Si existe una diferencia y se especificó transacción de ajuste
      if (rec.differenceAmount !== 0 && !rec.adjustmentTransactionId) {
        const adjTxId = `tx-rec-adj-${rec.cardId}-${Date.now()}`;
        rec.adjustmentTransactionId = adjTxId;

        // Registrar transacción de ajuste en el libro mayor de auditoría
        await db.runAsync(
          `INSERT INTO transactions (
            id, account_id, card_id, type, amount, category_id, description, notes, date,
            to_account_id, card_purchase_id, card_installment_id, statement_id, principal_amount, interest_amount, gmf_amount, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            adjTxId,
            null,
            rec.cardId,
            'balance_adjustment',
            Math.abs(rec.differenceAmount),
            'cat-financial',
            'Ajuste de Conciliación Bancaria',
            rec.notes || `Diferencia de conciliación con extracto bancario ($${rec.differenceAmount})`,
            rec.reconciliationDate,
            null,
            null,
            null,
            rec.statementId || null,
            Math.abs(rec.differenceAmount),
            0,
            0,
            now,
          ]
        );

        // Aplicar ajuste al cupo disponible de la tarjeta
        // Si la deuda bancaria es mayor (diff > 0), el cupo disponible se reduce.
        // Si la deuda bancaria es menor (diff < 0), el cupo disponible aumenta.
        await db.runAsync(
          'UPDATE credit_cards SET available_limit = MAX(0, MIN(credit_limit, available_limit - ?)) WHERE id = ?',
          [rec.differenceAmount, rec.cardId]
        );
      }

      // 2. Insertar registro en card_reconciliations
      await db.runAsync(
        `INSERT INTO card_reconciliations (
          id, card_id, statement_id, reconciliation_date, app_calculated_debt,
          bank_reported_debt, difference_amount, adjustment_transaction_id, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          rec.id,
          rec.cardId,
          rec.statementId || null,
          rec.reconciliationDate,
          rec.appCalculatedDebt,
          rec.bankReportedDebt,
          rec.differenceAmount,
          rec.adjustmentTransactionId || null,
          rec.notes || null,
          rec.createdAt || now,
        ]
      );
    });
  },

  /**
   * Obtiene el historial de conciliaciones de una tarjeta
   */
  async getReconciliationsForCard(cardId: string): Promise<CardReconciliation[]> {
    const db = await getDatabase();
    const rows = await db.getAllAsync<{
      id: string;
      card_id: string;
      statement_id: string | null;
      reconciliation_date: string;
      app_calculated_debt: number;
      bank_reported_debt: number;
      difference_amount: number;
      adjustment_transaction_id: string | null;
      notes: string | null;
      created_at: string;
    }>(
      'SELECT * FROM card_reconciliations WHERE card_id = ? ORDER BY reconciliation_date DESC',
      [cardId]
    );

    return rows.map((r) => ({
      id: r.id,
      cardId: r.card_id,
      statementId: r.statement_id || undefined,
      reconciliationDate: r.reconciliation_date,
      appCalculatedDebt: r.app_calculated_debt,
      bankReportedDebt: r.bank_reported_debt,
      differenceAmount: r.difference_amount,
      adjustmentTransactionId: r.adjustment_transaction_id || undefined,
      notes: r.notes || undefined,
      createdAt: r.created_at,
    }));
  },
};
