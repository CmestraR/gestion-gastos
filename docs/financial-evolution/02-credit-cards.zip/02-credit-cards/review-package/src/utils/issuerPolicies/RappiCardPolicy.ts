import type {
  CreditCardIssuerPolicy,
  StatementAllocationContext,
  AllocationResult,
  AllocationConcept,
} from './types.ts';

export class RappiCardPolicy implements CreditCardIssuerPolicy {
  readonly issuerId = 'rappicard';
  readonly issuerName = 'RappiCard';
  readonly supportsDirectedPayment = false;
  readonly supportsAlternativePayment = true; // Soportado conceptualmente
  readonly supportsEarlyPayment = true;
  readonly allocationOrder: AllocationConcept[] = [
    'late_interest',
    'current_interest',
    'taxes_and_fees',
    'handling_fee',
    'principal',
  ];

  allocatePayment(
    paymentAmount: number,
    ctx: StatementAllocationContext,
    _options?: { isDirected?: boolean; targetPurchaseId?: string }
  ): AllocationResult {
    let remainingPayment = Math.max(0, +paymentAmount.toFixed(2));
    let lateInterestApplied = 0;
    let currentInterestApplied = 0;
    let taxesAndFeesApplied = 0;
    let handlingFeeApplied = 0;
    let principalApplied = 0;

    // Regla RappiCard: El pago mínimo cubre mora, intereses, impuestos y comisiones.
    // Todo pago por encima del pago mínimo o posterior a cubrir los cargos del mes se imputa DIRECTAMENTE a capital.
    const unpaidLateInterest = Math.max(0, ctx.lateInterest);
    const unpaidCurrentInterest = Math.max(0, ctx.currentInterest);
    const unpaidTaxes = Math.max(0, ctx.taxesAndFees);
    const unpaidHandling = Math.max(0, ctx.handlingFee);

    // 1. Intereses de mora
    if (remainingPayment > 0 && unpaidLateInterest > 0) {
      lateInterestApplied = Math.min(remainingPayment, unpaidLateInterest);
      remainingPayment -= lateInterestApplied;
    }

    // 2. Intereses remuneratorios / corrientes
    if (remainingPayment > 0 && unpaidCurrentInterest > 0) {
      currentInterestApplied = Math.min(remainingPayment, unpaidCurrentInterest);
      remainingPayment -= currentInterestApplied;
    }

    // 3. Impuestos
    if (remainingPayment > 0 && unpaidTaxes > 0) {
      taxesAndFeesApplied = Math.min(remainingPayment, unpaidTaxes);
      remainingPayment -= taxesAndFeesApplied;
    }

    // 4. Comisiones / Cuota de manejo
    if (remainingPayment > 0 && unpaidHandling > 0) {
      handlingFeeApplied = Math.min(remainingPayment, unpaidHandling);
      remainingPayment -= handlingFeeApplied;
    }

    // 5. Todo el excedente (o pago por encima del mínimo) va 100% DIRECTAMENTE A CAPITAL
    if (remainingPayment > 0) {
      principalApplied = +remainingPayment.toFixed(2);
      remainingPayment = 0;
    }

    const totalStatementPaidNow = ctx.statementBalancePaid + paymentAmount;
    const remainingStatementBalance = Math.max(0, +(ctx.totalStatementBalance - totalStatementPaidNow).toFixed(2));
    const remainingMinimumPayment = Math.max(0, +(ctx.minimumPaymentOriginal - (ctx.minimumPaymentPaid + paymentAmount)).toFixed(2));
    const resultingAvailableLimit = Math.min(ctx.creditLimit, +(ctx.availableLimit + principalApplied).toFixed(2));

    return {
      totalPayment: paymentAmount,
      taxesAndFeesApplied: +taxesAndFeesApplied.toFixed(2),
      handlingFeeApplied: +handlingFeeApplied.toFixed(2),
      lateInterestApplied: +lateInterestApplied.toFixed(2),
      currentInterestApplied: +currentInterestApplied.toFixed(2),
      principalApplied: +principalApplied.toFixed(2),
      creditBalanceApplied: 0,
      remainingStatementBalance,
      remainingMinimumPayment,
      resultingAvailableLimit,
      isEstimated: false,
    };
  }
}
