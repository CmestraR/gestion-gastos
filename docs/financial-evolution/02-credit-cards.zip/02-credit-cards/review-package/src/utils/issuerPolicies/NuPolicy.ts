import type {
  CreditCardIssuerPolicy,
  StatementAllocationContext,
  AllocationResult,
  AllocationConcept,
} from './types.ts';

export class NuPolicy implements CreditCardIssuerPolicy {
  readonly issuerId = 'nu';
  readonly issuerName = 'Nu Colombia';
  readonly supportsDirectedPayment = true;
  readonly supportsAlternativePayment = false;
  readonly supportsEarlyPayment = true;
  readonly allocationOrder: AllocationConcept[] = [
    'taxes_and_fees',
    'handling_fee',
    'late_interest',
    'current_interest',
    'principal',
  ];

  allocatePayment(
    paymentAmount: number,
    ctx: StatementAllocationContext,
    options?: { isDirected?: boolean; targetPurchaseId?: string }
  ): AllocationResult {
    let remainingPayment = Math.max(0, +paymentAmount.toFixed(2));
    let taxesAndFeesApplied = 0;
    let handlingFeeApplied = 0;
    let lateInterestApplied = 0;
    let currentInterestApplied = 0;
    let principalApplied = 0;

    // Si ya se ha pagado parte del extracto, deducir proporcionalmente de conceptos pendientes
    const unpaidTaxes = Math.max(0, ctx.taxesAndFees);
    const unpaidHandling = Math.max(0, ctx.handlingFee);
    const unpaidLateInterest = Math.max(0, ctx.lateInterest);
    const unpaidCurrentInterest = Math.max(0, ctx.currentInterest);

    // 1. Impuestos y Cargos
    if (remainingPayment > 0 && unpaidTaxes > 0) {
      taxesAndFeesApplied = Math.min(remainingPayment, unpaidTaxes);
      remainingPayment -= taxesAndFeesApplied;
    }

    // 2. Cuota de Manejo / Comisiones
    if (remainingPayment > 0 && unpaidHandling > 0) {
      handlingFeeApplied = Math.min(remainingPayment, unpaidHandling);
      remainingPayment -= handlingFeeApplied;
    }

    // 3. Intereses de Mora
    if (remainingPayment > 0 && unpaidLateInterest > 0) {
      lateInterestApplied = Math.min(remainingPayment, unpaidLateInterest);
      remainingPayment -= lateInterestApplied;
    }

    // 4. Intereses Corrientes
    if (remainingPayment > 0 && unpaidCurrentInterest > 0) {
      currentInterestApplied = Math.min(remainingPayment, unpaidCurrentInterest);
      remainingPayment -= currentInterestApplied;
    }

    // 5. Todo el excedente se imputa a Capital (libera cupo)
    if (remainingPayment > 0) {
      principalApplied = +remainingPayment.toFixed(2);
      remainingPayment = 0;
    }

    const totalStatementPaidNow = ctx.statementBalancePaid + paymentAmount;
    const remainingStatementBalance = Math.max(0, +(ctx.totalStatementBalance - totalStatementPaidNow).toFixed(2));
    const remainingMinimumPayment = Math.max(0, +(ctx.minimumPaymentOriginal - (ctx.minimumPaymentPaid + paymentAmount)).toFixed(2));
    const resultingAvailableLimit = Math.min(ctx.creditLimit, +(ctx.availableLimit + principalApplied).toFixed(2));

    return {
      totalPayment: paymentAmount,
      taxesAndFeesApplied: +taxesAndFeesApplied.toFixed(2),
      handlingFeeApplied: +handlingFeeApplied.toFixed(2),
      lateInterestApplied: +lateInterestApplied.toFixed(2),
      currentInterestApplied: +currentInterestApplied.toFixed(2),
      principalApplied: +principalApplied.toFixed(2),
      creditBalanceApplied: 0,
      remainingStatementBalance,
      remainingMinimumPayment,
      resultingAvailableLimit,
      isEstimated: false,
    };
  }
}
